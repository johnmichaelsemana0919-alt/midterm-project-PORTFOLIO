<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "stacatalinahealthsystem";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch BHW names and medicine inventory
$bhw_names_result = $conn->query("SELECT bhw_id, bhw_name FROM bhw");
$medicines = $conn->query("SELECT inventory_id FROM medicineinventory");

// Handle form submission for adding medicine request
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit_request"])) {
    if (isset($_POST["bhw_name"]) && isset($_POST["inventory_id"]) && isset($_POST["req_quantity"]) && isset($_POST["patient_id"])) {
        $bhw_name = $_POST["bhw_name"];
        $inventory_id = $_POST["inventory_id"];
        $req_quantity = $_POST["req_quantity"];
        $patient_id = $_POST["patient_id"];

        $bhw_result = $conn->query("SELECT bhw_id, barangay FROM bhw WHERE bhw_name = '$bhw_name'");
        $bhw = $bhw_result->fetch_assoc();
        $bhw_id = $bhw['bhw_id'];
        $barangay = $bhw['barangay'];

        $check = $conn->query("SELECT * FROM requested_medicine 
            WHERE bhw_id = '$bhw_id' AND inventory_id = '$inventory_id' AND patient_id = '$patient_id'");

        if ($check->num_rows > 0) {
            $existing = $check->fetch_assoc();
            $new_quantity = $existing['req_quantity'] + $req_quantity;
            $update_sql = "UPDATE requested_medicine SET req_quantity = '$new_quantity' 
                WHERE request_id = '" . $existing['request_id'] . "'";
            $conn->query($update_sql);
        } else {
            $sql = "INSERT INTO requested_medicine (inventory_id, patient_id, bhw_id, req_quantity) 
                    VALUES ('$inventory_id', '$patient_id', '$bhw_id', '$req_quantity')";
            $conn->query($sql);
        }
    }
}

// Handle request removal
if (isset($_GET['remove_id'])) {
    $remove_id = $_GET['remove_id'];
    $conn->query("DELETE FROM requested_medicine WHERE request_id = '$remove_id'");
    header("Location: bhw_dashboard.php");
    exit();
}

$all_requests = $conn->query("SELECT * FROM requested_medicine ORDER BY request_id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>BHW Medicine Request</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { font-size: 0.9rem; background-color: rgba(1, 67, 19, 0.26);; }
        .container { max-width: 900px; position: relative; }
        .form-group { margin-bottom: 0.8rem; }
        .table { font-size: 0.85rem; background-color: #198754; color: white; }
        .table th, .table td { padding: 0.8rem; text-align: center; }
        .remove-btn { font-size: 0.75rem; background-color: #ff4d4d; color: white; border: none; cursor: pointer; }
        .remove-btn:hover { background-color: #ff1a1a; }
        .table th { background-color: #145d47; }
        .table tr:nth-child(even) { background-color: #28a745; }
        .table tr:nth-child(odd) { background-color: #198754; }
        .form-row { display: flex; justify-content: space-between; }
        .form-row .form-group { margin-right: 1rem; flex: 1; }
        .form-row .form-group:last-child { margin-right: 0; }
        .btn-submit { margin-top: 2.2rem; margin-left: 1rem; flex-shrink: 0; }

        .back-btn {
            background-color: #ff4d4d;
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .back-btn:hover {
            background-color:rgb(71, 5, 5);
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>
<div class="container mt-4">

    <!-- Back to Admin Dashboard Button -->
    <a href="admin_dashboard.php" class="btn btn-secondary btn-sm back-btn">← Back</a>

    <!-- Request New Medicine Form -->
    <h3 class="mb-3" style="color: #198754;">Request New Medicine</h3>
    <form method="POST">
        <div class="form-row">
            <div class="form-group col-md-3">
                <label for="bhw_name">BHW Name</label>
                <select class="form-control" id="bhw_name" name="bhw_name" required>
                    <option value="">-- Select BHW --</option>
                    <?php while ($bhw = $bhw_names_result->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($bhw['bhw_name']) ?>">
                            <?= htmlspecialchars($bhw['bhw_id']) ?> - <?= htmlspecialchars($bhw['bhw_name']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group col-md-3">
                <label for="inventory_id">Medicine Inventory ID</label>
                <select class="form-control" id="inventory_id" name="inventory_id" required>
                    <option value="">-- Select Medicine --</option>
                    <?php
                    $meds = $conn->query("SELECT inventory_id FROM medicineinventory");
                    while ($m = $meds->fetch_assoc()):
                    ?>
                        <option value="<?= $m['inventory_id'] ?>"><?= $m['inventory_id'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group col-md-2">
                <label for="req_quantity">Quantity</label>
                <input type="number" class="form-control" id="req_quantity" name="req_quantity" required min="1">
            </div>

            <div class="form-group col-md-2">
                <label for="patient_id">Patient ID</label>
                <select class="form-control" id="patient_id" name="patient_id" required>
                    <option value="">-- Select Patient --</option>
                    <?php
                    $patients = $conn->query("SELECT patient_id FROM patient WHERE patient_id BETWEEN 101 AND 130");
                    while ($p = $patients->fetch_assoc()):
                    ?>
                        <option value="<?= $p['patient_id'] ?>"><?= $p['patient_id'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group col-md-1">
                <button type="submit" name="submit_request" class="btn btn-primary btn-sm btn-submit">Submit</button>
            </div>
        </div>
    </form>

    <hr>

    <!-- Full Medicine Requests Table -->
    <h3 class="mb-3" style="color: #198754;">All Medicine Requests</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Request ID</th>
                <th>BHW ID</th>
                <th>Inventory ID</th>
                <th>Requested Quantity</th>
                <th>Patient ID</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($info = $all_requests->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($info['request_id']) ?></td>
                    <td><?= htmlspecialchars($info['bhw_id']) ?></td>
                    <td><?= htmlspecialchars($info['inventory_id']) ?></td>
                    <td><?= htmlspecialchars($info['req_quantity']) ?></td>
                    <td><?= htmlspecialchars($info['patient_id']) ?></td>
                    <td>
                        <a href="?remove_id=<?= $info['request_id'] ?>" class="remove-btn">Remove</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>
</body>
</html>

<?php
$conn->close();
?>
