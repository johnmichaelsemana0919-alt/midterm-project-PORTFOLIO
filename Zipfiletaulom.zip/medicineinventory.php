<?php
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert new inventory entry
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_inventory'])) {
    $medicine_id = $_POST['medicine_id'];
    $med_quantity = $_POST['med_quantity'];
    $expiration_date = $_POST['expiration_date'];
    $storage_type = $_POST['storage_type'];

    $stmt = $conn->prepare("INSERT INTO medicineinventory (medicine_id, med_quantity, expiration_date, storage_type) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $medicine_id, $med_quantity, $expiration_date, $storage_type);
    $stmt->execute();
    $stmt->close();
}

// Update existing inventory
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_inventory'])) {
    $inventory_id = $_POST['inventory_id'];
    $med_quantity = $_POST['med_quantity'];

    $stmt = $conn->prepare("UPDATE medicineinventory SET med_quantity = ? WHERE inventory_id = ?");
    $stmt->bind_param("ii", $med_quantity, $inventory_id);
    $stmt->execute();
    $stmt->close();
}

// Fetch all inventory records
$inventoryResult = $conn->query("SELECT * FROM medicineinventory");

// Fetch medicine IDs
$medicineResult = $conn->query("SELECT medicine_id FROM medicineinventory");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Medicine Inventory Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
           background-color: rgba(1, 67, 19, 0.26);;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        th {
            background: #198754;
            color: #fff;
        }
        form {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }
        label {
            width: auto;
            font-weight: bold;
        }
        input[type="number"],
        input[type="text"],
        input[type="date"],
        select {
            width: 200px;
            padding: 6px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 8px 15px;
            background: #198754;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-btn {
            background: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
        .back-btn {
            background-color: red;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            position: fixed;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>

<!-- Back Button -->
<a href="admin_dashboard.php"><button class="back-btn">Back</button></a>

<h2>Medicine Inventory Dashboard</h2>

<!-- Add Inventory Form -->
<form method="POST">
    <input type="hidden" name="add_inventory" value="1">

    <label>Medicine ID</label>
    <select name="medicine_id" required>
        <option value="" disabled selected>Select Medicine</option>
        <?php while ($row = $medicineResult->fetch_assoc()): ?>
            <option value="<?= $row['medicine_id'] ?>"><?= $row['medicine_id'] ?></option>
        <?php endwhile; ?>
    </select>

    <label>Quantity</label>
    <input type="number" name="med_quantity" required>

    <label>Expiration</label>
    <input type="date" name="expiration_date" required>

    <label>Storage</label>
    <input type="text" name="storage_type" required>

    <button type="submit">Add</button>
</form>

<!-- Update Inventory Form -->
<form method="POST">
    <input type="hidden" name="update_inventory" value="1">

    <label>Inventory ID</label>
    <input type="number" name="inventory_id" required>

    <label>New Quantity</label>
    <input type="number" name="med_quantity" required>

    <button type="submit">Update</button>
</form>

<!-- Inventory Table -->
<h3>Existing Inventory</h3>
<table>
    <tr>
        <th>Inventory ID</th>
        <th>Medicine ID</th>
        <th>Quantity</th>
        <th>Expiration</th>
        <th>Storage Type</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $inventoryResult->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['inventory_id']) ?></td>
            <td><?= htmlspecialchars($row['medicine_id']) ?></td>
            <td><?= htmlspecialchars($row['med_quantity']) ?></td>
            <td><?= htmlspecialchars($row['expiration_date']) ?></td>
            <td><?= htmlspecialchars($row['storage_type']) ?></td>
            <td><a href="?delete=<?= $row['inventory_id'] ?>" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</a></td>
        </tr>
    <?php endwhile; ?>
</table>

<?php
// Handle deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM medicineinventory WHERE inventory_id = $id");
}
$conn->close();
?>

</body>
</html>
