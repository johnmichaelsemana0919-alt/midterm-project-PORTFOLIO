<?php
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert new prescription
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_prescription'])) {
    $prescription_id = $_POST['prescription_id'];
    $patient_id = $_POST['patient_id'];
    $doc_id = $_POST['doc_id'];
    $medicine_id = $_POST['medicine_id']; // Only one medicine id
    $date_issued = $_POST['date_issued'];
    $instruction = $_POST['instruction'];
    $med_quantity = $_POST['med_quantity'];

    // Insert the prescription
    $stmt = $conn->prepare("INSERT INTO prescription (prescription_id, patient_id, doc_id, medicine_id, date_issued, instruction, med_quantity) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiisssi", $prescription_id, $patient_id, $doc_id, $medicine_id, $date_issued, $instruction, $med_quantity);
    $stmt->execute();
    $stmt->close();
}

// Delete prescription
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM prescription WHERE prescription_id = $id");
}

$prescriptions = $conn->query("SELECT * FROM prescription");

// Fetch doctors from the database
$doctorQuery = "SELECT doc_id, CONCAT(f_name, ' ', m_name, ' ', l_name) AS full_name FROM doctor";
$doctorResult = $conn->query($doctorQuery);

// Fetch medicines from the medicine inventory table
$medicineQuery = "SELECT medicine_id FROM medicineinventory";
$medicineResult = $conn->query($medicineQuery);

// Fetch patients from the patient table
$patientQuery = "SELECT patient_id, CONCAT(first_name, ' ', last_name) AS patient_name FROM patient";
$patientResult = $conn->query($patientQuery);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Prescription Dashboard</title>
    <style>
        body {
            font-family: Arial;
           background-color: rgba(1, 67, 19, 0.26);;
            padding: 20px;
            position: relative;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        th {
            background: #198754;
            color: #fff;
        }
        form {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        input, select {
            padding: 8px;
            width: 99%;
            margin-bottom: 10px;
        }
        button {
            padding: 10px;
            background: #198754;
            color: white;
            border: none;
            border-radius: 5px;
        }
        .delete-btn {
            background: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        /* Back Button Styling */
        .back-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: red;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .back-btn:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>

<!-- Back Button -->
<a href="admin_dashboard.php"><button class="back-btn">Back</button></a>

<h2>Prescription Dashboard</h2>

<form method="POST">
    <input type="hidden" name="add_prescription" value="1">

    <label>Prescription ID</label>
    <input type="number" name="prescription_id" required>

    <label>Patient</label>
    <select name="patient_id" required>
        <option value="" disabled selected>Select Patient</option>
        <?php while ($row = $patientResult->fetch_assoc()): ?>
            <option value="<?= $row['patient_id'] ?>"><?= htmlspecialchars($row['patient_name']) ?></option>
        <?php endwhile; ?>
    </select>

    <label>Doctor</label>
    <select name="doc_id" required>
        <option value="" disabled selected>Select Doctor</option>
        <?php while ($row = $doctorResult->fetch_assoc()): ?>
            <option value="<?= $row['doc_id'] ?>"><?= htmlspecialchars($row['full_name']) ?></option>
        <?php endwhile; ?>
    </select>

    <label>Medicine</label>
    <select name="medicine_id" required>
        <option value="" disabled selected>Select Medicine</option>
        <?php while ($row = $medicineResult->fetch_assoc()): ?>
            <option value="<?= $row['medicine_id'] ?>"><?= $row['medicine_id'] ?></option>
        <?php endwhile; ?>
    </select>

    <label>Date Issued</label>
    <input type="date" name="date_issued" required>

    <label>Instruction</label>
    <input type="text" name="instruction" required>

    <label>Medicine Quantity</label>
    <input type="number" name="med_quantity" required>

    <button type="submit">Add Prescription</button>
</form>

<table>
    <tr>
        <th>Prescription ID</th>
        <th>Patient ID</th>
        <th>Doctor ID</th>
        <th>Medicine ID</th>
        <th>Date Issued</th>
        <th>Instruction</th>
        <th>Medicine Quantity</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $prescriptions->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['prescription_id']) ?></td>
        <td><?= htmlspecialchars($row['patient_id']) ?></td>
        <td><?= htmlspecialchars($row['doc_id']) ?></td>
        <td><?= htmlspecialchars($row['medicine_id']) ?></td>
        <td><?= htmlspecialchars($row['date_issued']) ?></td>
        <td><?= htmlspecialchars($row['instruction']) ?></td>
        <td><?= htmlspecialchars($row['med_quantity']) ?></td>
        <td><a href="?delete=<?= $row['prescription_id'] ?>" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</a></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php $conn->close(); ?>

</body>
</html>
