-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2025 at 04:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stacatalinahealthsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE `assessment` (
  `ass_id` int(11) NOT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `ass_date` date DEFAULT NULL,
  `heart_rate` varchar(6) DEFAULT NULL,
  `temperature` varchar(10) DEFAULT NULL,
  `height` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `blood_pressure` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`ass_id`, `doc_id`, `patient_id`, `ass_date`, `heart_rate`, `temperature`, `height`, `weight`, `blood_pressure`) VALUES
(10001, 3, 101, '2025-01-10', '120bpm', '36.6', 160.5, 55.4, '110/70'),
(10002, 5, 102, '2025-02-14', '140bpm', '37.4', 175.2, 78.9, '130/85'),
(10003, 1, 103, '2025-03-01', '115bpm', '36.9', 162, 60, '120/80'),
(10004, 7, 104, '2025-01-27', '130bpm', '37.2', 168.7, 70.5, '125/85'),
(10005, 8, 105, '2025-02-08', '145bpm', '36.8', 159.3, 58.2, '110/70'),
(10006, 9, 106, '2025-03-14', '138bpm', '37.1', 174.6, 85, '130/90'),
(10007, 4, 107, '2025-01-16', '122bpm', '36.5', 161.4, 65.1, '120/80'),
(10008, 10, 108, '2025-02-21', '135bpm', '37.0', 178.9, 88.3, '140/90'),
(10009, 6, 109, '2025-03-11', '125bpm', '36.7', 165.7, 66, '115/75'),
(10010, 2, 110, '2025-02-01', '128bpm', '36.6', 167, 72.2, '120/80'),
(10011, 11, 111, '2025-01-12', '140bpm', '36.9', 163, 58, '110/70'),
(10012, 12, 112, '2025-02-15', '138bpm', '37.5', 180.2, 92.5, '145/95'),
(10013, 13, 113, '2025-03-03', '118bpm', '36.8', 160.9, 59, '115/75'),
(10014, 14, 114, '2025-02-22', '142bpm', '37.2', 176.3, 83.4, '140/90'),
(10015, 15, 115, '2025-01-18', '123bpm', '36.6', 158.1, 60.8, '120/80'),
(10016, 16, 116, '2025-03-09', '130bpm', '36.7', 170.5, 75, '125/85'),
(10017, 17, 117, '2025-02-19', '120bpm', '36.5', 162.3, 62.7, '115/75'),
(10018, 18, 118, '2025-03-10', '139bpm', '37.3', 173.6, 84, '140/95'),
(10019, 19, 119, '2025-01-21', '137bpm', '36.9', 168.8, 77.5, '135/90'),
(10020, 20, 120, '2025-02-28', '127bpm', '36.6', 165, 68.3, '120/80'),
(10021, 21, 121, '2025-01-29', '140bpm', '37.1', 160.4, 70.2, '130/85'),
(10022, 22, 122, '2025-03-04', '126bpm', '36.7', 172.7, 79, '120/80'),
(10023, 23, 123, '2025-01-26', '133bpm', '36.8', 159.6, 61.3, '110/70'),
(10024, 24, 124, '2025-02-13', '141bpm', '37.4', 175.8, 88.7, '145/95'),
(10025, 25, 125, '2025-03-05', '136bpm', '36.9', 161.7, 64.9, '120/80'),
(10026, 26, 126, '2025-01-31', '122bpm', '36.6', 169.3, 74.5, '115/75'),
(10027, 27, 127, '2025-02-09', '134bpm', '37.2', 158.4, 59.8, '110/70'),
(10028, 28, 128, '2025-03-07', '143bpm', '37.3', 177, 90, '145/95'),
(10029, 29, 129, '2025-02-05', '128bpm', '36.8', 164.2, 67.3, '120/80'),
(10030, 30, 130, '2025-03-15', '129bpm', '36.7', 172, 78.1, '125/85');

-- --------------------------------------------------------

--
-- Table structure for table `bhw`
--

CREATE TABLE `bhw` (
  `bhw_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `inventory_id` int(11) DEFAULT NULL,
  `bhw_name` varchar(150) DEFAULT NULL,
  `barangay` varchar(30) DEFAULT NULL,
  `req_quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doc_id` int(11) NOT NULL,
  `position` varchar(30) DEFAULT NULL,
  `f_name` varchar(50) DEFAULT NULL,
  `m_name` varchar(30) DEFAULT NULL,
  `l_name` varchar(30) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `address` varchar(120) DEFAULT NULL,
  `contact_no` bigint(20) DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `scheduled_event` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_id`, `position`, `f_name`, `m_name`, `l_name`, `birthdate`, `address`, `contact_no`, `gender`, `scheduled_event`) VALUES
(1, 'Doctor1', 'Jose', 'Protacio', 'Dela Cruz', '1981-07-24', 'Cabanglutan, San Juan, Ilocos Sur', 9616324593, 'Male', '2025-03-20'),
(2, 'Doctor2', 'Andres', 'De Castro', 'Reyes', '1986-06-07', 'Cabaroan, Sta. Catalina, Ilocos Sur', 9194037711, 'Male', '2025-02-23'),
(3, 'Doctor3', 'Emilio', 'Aguinaldo', 'Santos', '1978-03-12', 'Tamag, Vigan City', 9354827432, 'Male', '2025-04-10'),
(4, 'Doctor4', 'Maria', 'Claridad', 'Garcia', '1982-05-05', 'Bantay, Ilocos Sur', 9467239234, 'Female', '2025-03-15'),
(5, 'Doctor5', 'Ramon', 'Santos', 'Lopez', '1980-01-21', 'San Ildefonso, Ilocos Sur', 9278283472, 'Male', '2025-02-28'),
(6, 'Doctor6', 'Pilar', 'Santos', 'Garcia', '1987-08-03', 'Narvacan, Ilocos Sur', 9653489234, 'Female', '2025-03-25'),
(7, 'Doctor7', 'Jaime', 'De Vera', 'Torres', '1976-02-16', 'San Vicente, Ilocos Sur', 9078652451, 'Male', '2025-04-18'),
(8, 'Doctor8', 'Karen', 'Teresa', 'Castro', '1985-12-10', 'Caoayan, Ilocos Sur', 9128374823, 'Female', '2025-03-05'),
(9, 'Doctor9', 'Arnold', 'Estrella', 'Ramos', '1979-04-30', 'Tagudin, Ilocos Sur', 9918237423, 'Male', '2025-02-14'),
(10, 'Doctor10', 'Lucia', 'Bautista', 'Fernandez', '1984-07-01', 'Sta. Lucia, Ilocos Sur', 9283746129, 'Female', '2025-04-20'),
(11, 'Doctor11', 'Daniel', 'Pascual', 'Bautista', '1983-06-18', 'Magsingal, Ilocos Sur', 9012354892, 'Male', '2025-03-30'),
(12, 'Doctor12', 'Estella', 'Villanueva', 'Santos', '1986-03-09', 'Lidlidda, Ilocos Sur', 9718234672, 'Female', '2025-03-12'),
(13, 'Doctor13', 'Roberto', 'Bartolome', 'De Leon', '1975-05-14', 'Sinait, Ilocos Sur', 9812436482, 'Male', '2025-03-17'),
(14, 'Doctor14', 'Nina', 'Santiago', 'Gonzalez', '1989-10-23', 'Santa, Ilocos Sur', 9192834578, 'Female', '2025-03-19'),
(15, 'Doctor15', 'Victor', 'Pascual', 'Lopez', '1981-09-05', 'Galimuyod, Ilocos Sur', 9217826432, 'Male', '2025-02-19'),
(16, 'Doctor16', 'Marites', 'Enriquez', 'Garcia', '1982-01-30', 'Nagbukel, Ilocos Sur', 9437482901, 'Female', '2025-04-01'),
(17, 'Doctor17', 'Gregorio', 'De Luna', 'Santos', '1980-04-06', 'Burgos, Ilocos Sur', 9018273463, 'Male', '2025-03-10'),
(18, 'Doctor18', 'Angelica', 'Morales', 'Ramos', '1984-02-02', 'Santiago, Ilocos Sur', 9128462736, 'Female', '2025-02-21'),
(19, 'Doctor19', 'Ernesto', 'Lopez', 'Ramos', '1977-11-11', 'Quirino, Ilocos Sur', 9612874322, 'Male', '2025-04-05'),
(20, 'Doctor20', 'Jennifer', 'Bautista', 'Castro', '1983-08-09', 'Suyo, Ilocos Sur', 9072837482, 'Female', '2025-03-03'),
(21, 'Doctor21', 'Miguel', 'Francisco', 'Reyes', '1986-07-14', 'Alilem, Ilocos Sur', 9128723487, 'Male', '2025-04-08'),
(22, 'Doctor22', 'Teresa', 'Balagtas', 'Santos', '1985-03-08', 'Cervantes, Ilocos Sur', 9218462375, 'Female', '2025-03-08'),
(23, 'Doctor23', 'Christian', 'Villamor', 'Ramos', '1987-12-18', 'Salcedo, Ilocos Sur', 9418273645, 'Male', '2025-03-28'),
(24, 'Doctor24', 'Fatima', 'De Leon', 'Santos', '1988-04-04', 'Sigay, Ilocos Sur', 9378236452, 'Female', '2025-04-12'),
(25, 'Doctor25', 'Dennis', 'Galang', 'Castro', '1982-05-17', 'Gregorio del Pilar, Ilocos Sur', 9128374561, 'Male', '2025-03-09'),
(26, 'Doctor26', 'Jessica', 'Cabral', 'Santos', '1984-06-11', 'Lidlidda, Ilocos Sur', 9612734829, 'Female', '2025-02-26'),
(27, 'Doctor27', 'Arnold', 'Ilagan', 'Gonzalez', '1980-10-30', 'Sugpon, Ilocos Sur', 9098723481, 'Male', '2025-04-15'),
(28, 'Doctor28', 'Michelle', 'Uson', 'Ramos', '1985-09-03', 'Cervantes, Ilocos Sur', 9187236482, 'Female', '2025-03-07'),
(29, 'Doctor29', 'Nathaniel', 'Cruz', 'Santos', '1981-11-25', 'Sta. Cruz, Ilocos Sur', 9287123487, 'Male', '2025-03-14'),
(30, 'Doctor30', 'Rowena', 'Lacson', 'Garcia', '1986-02-27', 'Banayoyo, Ilocos Sur', 9456123872, 'Female', '2025-03-22');

-- --------------------------------------------------------

--
-- Table structure for table `medhistory`
--

CREATE TABLE `medhistory` (
  `history_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `ass_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `medicine_id` int(11) NOT NULL,
  `brand_name` varchar(30) DEFAULT NULL,
  `generic_name` varchar(35) DEFAULT NULL,
  `description` varchar(150) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `dosage_form` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicineinventory`
--

CREATE TABLE `medicineinventory` (
  `inventory_id` int(11) NOT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `med_quantity` int(11) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `storage_type` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE `nurse` (
  `nurse_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `position` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`nurse_id`, `patient_id`, `doc_id`, `full_name`, `position`) VALUES
(20001, 101, 1, 'Ben Morales', 'Nurse 1'),
(20002, 102, 2, 'Elaine Sarmiento', 'Nurse 2'),
(20003, 103, 3, 'Johnlee Santos', 'Nurse 3'),
(20004, 104, 4, 'Kristine Ramos', 'Nurse 1'),
(20005, 105, 5, 'Marcus Evangelista', 'Nurse 2'),
(20006, 106, 6, 'Angelica Cruz', 'Nurse 3'),
(20007, 107, 7, 'Jerome Dela Peña', 'Nurse 1'),
(20008, 108, 8, 'Marian Alvarado', 'Nurse 2'),
(20009, 109, 9, 'Dennis Catubay', 'Nurse 3'),
(20010, 110, 10, 'Alyssa Reyes', 'Nurse 1'),
(20011, 111, 11, 'Cristopher Villanueva', 'Nurse 2'),
(20012, 112, 12, 'Lyka Mendoza', 'Nurse 3'),
(20013, 113, 13, 'Kenneth Jimenez', 'Nurse 1'),
(20014, 114, 14, 'Erika dela Cruz', 'Nurse 2'),
(20015, 115, 15, 'Jonas Fortunato', 'Nurse 3'),
(20016, 116, 16, 'Tricia Manaloto', 'Nurse 1'),
(20017, 117, 17, 'Randy Sabangan', 'Nurse 2'),
(20018, 118, 18, 'Julie Ann Macaraeg', 'Nurse 3'),
(20019, 119, 19, 'Alvin Mateo', 'Nurse 1'),
(20020, 120, 20, 'Katrina Ocampo', 'Nurse 2'),
(20021, 121, 21, 'Noel Aquino', 'Nurse 3'),
(20022, 122, 22, 'Michelle Realin', 'Nurse 1'),
(20023, 123, 23, 'Carlo Bugarin', 'Nurse 2'),
(20024, 124, 24, 'Charmaine Padilla', 'Nurse 3'),
(20025, 125, 25, 'Jayson Dimaculangan', 'Nurse 1'),
(20026, 126, 26, 'Ana Beatriz Pascual', 'Nurse 2'),
(20027, 127, 27, 'Jasper Dayrit', 'Nurse 3'),
(20028, 128, 28, 'Maricel Florentino', 'Nurse 1'),
(20029, 129, 29, 'Dominic Eustaquio', 'Nurse 2'),
(20030, 130, 30, 'Fely Gomez', 'Nurse 3');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `contact` bigint(20) DEFAULT NULL,
  `guardian_name` varchar(120) DEFAULT NULL,
  `guard_type` varchar(15) DEFAULT NULL,
  `blood_type` varchar(3) DEFAULT NULL,
  `med_history` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `doc_id`, `first_name`, `middle_name`, `last_name`, `birthdate`, `gender`, `contact`, `guardian_name`, `guard_type`, `blood_type`, `med_history`) VALUES
(101, 3, 'Ana', 'Ramirez', 'Cruz', '1994-01-12', 'Female', 9123456781, 'Ramon Cruz', 'Father', 'A+', 'Diabetes'),
(102, 5, 'Carlos', 'Tan', 'Santos', '1987-08-09', 'Male', 9128463721, 'Maria Santos', 'Mother', 'B+', 'Asthma'),
(103, 1, 'Liza', 'Vera', 'Reyes', '1979-03-21', 'Female', 9218374652, 'Jaime Reyes', 'Husband', 'AB+', 'Hypertension'),
(104, 7, 'Daryl', 'Gomez', 'Valdez', '2002-06-17', 'Male', 9317263418, 'Gina Valdez', 'Mother', 'O-', 'Allergies'),
(105, 8, 'Katrina', 'Diane', 'Dizon', '1995-11-11', 'Female', 9416283741, 'Peter Dizon', 'Brother', 'A-', 'Asthma'),
(106, 9, 'Jordan', 'Pedro', 'Villanueva', '1983-12-25', 'Male', 9128374658, 'Anna Villanueva', 'Spouse', 'O+', 'High Cholesterol'),
(107, 4, 'Cecilia', 'Quintin', 'Mercado', '1998-07-15', 'Female', 9518736425, 'Juan Mercado', 'Father', 'B-', 'Ulcer'),
(108, 10, 'Mario', 'Jose', 'Alonzo', '1980-02-13', 'Male', 9618273645, 'Rosa Alonzo', 'Wife', 'AB-', 'Asthma'),
(109, 6, 'Brenda', 'Rosario', 'Cuevas', '1993-05-08', 'Female', 9718236458, 'Lester Cuevas', 'Husband', 'O+', 'Migraine'),
(110, 2, 'Ken', 'David', 'Estrada', '2000-09-26', 'Male', 9817283461, 'Elvie Estrada', 'Mother', 'A+', 'Diabetes'),
(111, 11, 'Lani', 'Geraldine', 'Mateo', '1986-01-07', 'Female', 9127374628, 'Carlo Mateo', 'Husband', 'B+', 'Hypotension'),
(112, 12, 'Rick', 'Henry', 'Gonzales', '1991-10-30', 'Male', 9218273612, 'Juliet Gonzales', 'Wife', 'O-', 'Hepatitis B'),
(113, 13, 'Paula', 'Karen', 'Robles', '1989-06-04', 'Female', 9327384721, 'Eric Robles', 'Father', 'A+', 'Anemia'),
(114, 14, 'Joel', 'Manuel', 'Austria', '1978-12-12', 'Male', 9128374632, 'Sonia Austria', 'Wife', 'AB+', 'Hypertension'),
(115, 15, 'Rica', 'Belen', 'Dimaculangan', '1996-03-27', 'Female', 9273846124, 'Oscar Dimaculangan', 'Father', 'B-', 'Ulcer'),
(116, 16, 'Gilbert', 'Tomas', 'Umali', '1990-04-19', 'Male', 9182736482, 'Alma Umali', 'Spouse', 'O+', 'Asthma'),
(117, 17, 'Hazel', 'Ann', 'Aquino', '2001-05-16', 'Female', 9412384751, 'Fred Aquino', 'Father', 'O-', 'Diabetes'),
(118, 18, 'Benny', 'Carlos', 'Rosales', '1985-08-08', 'Male', 9517283649, 'Marilou Rosales', 'Wife', 'A-', 'Hypertension'),
(119, 19, 'Monique', 'Eliza', 'Santos', '1992-09-10', 'Female', 9618237456, 'Benjamin Santos', 'Father', 'AB+', 'Heart Disease'),
(120, 20, 'Dino', 'Ricardo', 'Angeles', '1997-07-22', 'Male', 9712834615, 'Rea Angeles', 'Mother', 'B+', 'Hepatitis A'),
(121, 21, 'Celine', 'Ursula', 'Chua', '1984-02-18', 'Female', 9817234591, 'Bryan Chua', 'Husband', 'O+', 'High Cholesterol'),
(122, 22, 'Marvin', 'Vicente', 'Vega', '1977-11-30', 'Male', 9128374681, 'Linda Vega', 'Spouse', 'A+', 'Ulcer'),
(123, 23, 'Lianne', 'Carla', 'Fabros', '1999-03-02', 'Female', 9218736452, 'Raul Fabros', 'Father', 'B-', 'Asthma'),
(124, 24, 'Enzo', 'Xander', 'Sevilla', '1994-12-11', 'Male', 9318374612, 'Mylene Sevilla', 'Wife', 'AB-', 'Diabetes'),
(125, 25, 'Tanya', 'Zenaida', 'Guevarra', '1988-06-29', 'Female', 9418273641, 'Isko Guevarra', 'Father', 'A-', 'Hypertension'),
(126, 26, 'Marco', 'Yves', 'Beltran', '1982-01-06', 'Male', 9518273649, 'Leila Beltran', 'Spouse', 'O+', 'Asthma'),
(127, 27, 'Justine', 'Bianca', 'De Vera', '2003-05-14', 'Female', 9612738465, 'Ronaldo De Vera', 'Father', 'O-', 'Allergies'),
(128, 28, 'Allan', 'Ramon', 'Agbayani', '1976-10-05', 'Male', 9781237465, 'Edith Agbayani', 'Wife', 'B+', 'Diabetes'),
(129, 29, 'Denise', 'Lyn', 'Castro', '1995-08-23', 'Female', 9818273648, 'Paolo Castro', 'Spouse', 'AB+', 'Heart Disease'),
(130, 30, 'Ricky', 'Steven', 'Navarro', '1981-04-28', 'Male', 9912873641, 'Melba Navarro', 'Wife', 'A+', 'Hypertension');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `prescription_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `date_issued` date DEFAULT NULL,
  `instruction` varchar(300) DEFAULT NULL,
  `med_quantity` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration_tbl`
--

CREATE TABLE `registration_tbl` (
  `idnum` varchar(20) NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration_tbl`
--

INSERT INTO `registration_tbl` (`idnum`, `username`, `email`, `password`) VALUES
('1234', 'frederick', 'frederickpaiste33@gmail.com', '$2y$10$ohFAwzFnOu4mv0Sb5y7yXeTM0Zaeijt2OYwC84GVCIgsCKBvcLE7O'),
('12345', 'frederick1', 'frederick@gmail.com', '$2y$10$IIfGsNckanfppNsyqMfc3uy7Ve8vEUHh0t4MNi38GMYy7ps6Ah5dW');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessment`
--
ALTER TABLE `assessment`
  ADD PRIMARY KEY (`ass_id`),
  ADD KEY `FK_assessment_doctor` (`doc_id`),
  ADD KEY `FK_assessment_patient` (`patient_id`);

--
-- Indexes for table `bhw`
--
ALTER TABLE `bhw`
  ADD PRIMARY KEY (`bhw_id`),
  ADD KEY `FK_bhw_patient` (`patient_id`),
  ADD KEY `FK_bhw_medicineinventory` (`inventory_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `medhistory`
--
ALTER TABLE `medhistory`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `FK_med_history_patient` (`patient_id`),
  ADD KEY `FK_med_history_assessment` (`ass_id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indexes for table `medicineinventory`
--
ALTER TABLE `medicineinventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `medicine_id` (`medicine_id`);

--
-- Indexes for table `nurse`
--
ALTER TABLE `nurse`
  ADD PRIMARY KEY (`nurse_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`),
  ADD KEY `doc_id` (`doc_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`prescription_id`),
  ADD KEY `FK_prescription_patient` (`patient_id`),
  ADD KEY `FK_prescription_doctor` (`doc_id`),
  ADD KEY `FK_prescription_medicine` (`medicine_id`);

--
-- Indexes for table `registration_tbl`
--
ALTER TABLE `registration_tbl`
  ADD PRIMARY KEY (`idnum`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assessment`
--
ALTER TABLE `assessment`
  ADD CONSTRAINT `FK_assessment_doctor` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_assessment_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bhw`
--
ALTER TABLE `bhw`
  ADD CONSTRAINT `FK_bhw_medicineinventory` FOREIGN KEY (`inventory_id`) REFERENCES `medicineinventory` (`inventory_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_bhw_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `medhistory`
--
ALTER TABLE `medhistory`
  ADD CONSTRAINT `FK_med_history_assessment` FOREIGN KEY (`ass_id`) REFERENCES `assessment` (`Ass_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_med_history_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `medicineinventory`
--
ALTER TABLE `medicineinventory`
  ADD CONSTRAINT `medicine_id` FOREIGN KEY (`medicine_id`) REFERENCES `medicine` (`medicine_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nurse`
--
ALTER TABLE `nurse`
  ADD CONSTRAINT `doc_id` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `S_id` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `FK_prescription_doctor` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_prescription_medicine` FOREIGN KEY (`medicine_id`) REFERENCES `medicine` (`medicine_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_prescription_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
