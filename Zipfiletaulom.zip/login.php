<?php
// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $idnum = trim($_POST['idnum']);
    $password = trim($_POST['password']);

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare a query to fetch the user by ID number and username
    $sql = "SELECT * FROM registration_tbl WHERE idnum = ? AND username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $idnum, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a matching user was found
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {
            // Set session variables
            $_SESSION['username'] = $row['username'];
            $_SESSION['idnum'] = $row['idnum'];
            $_SESSION['role'] = 'admin'; // assuming it's an admin login

            // Redirect to the admin dashboard
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $message = "Incorrect password.";
        }
    } else {
        $message = "Invalid username or ID number.";
    }

    $stmt->close();
    $conn->close();

    // Show alert and redirect back to login
    echo "<script>alert('$message'); window.location.href = 'LoginReg_index.html';</script>";
    exit();
}
?>
