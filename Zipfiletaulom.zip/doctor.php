<?php
session_start();
$message = "";

// If login form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST['doctor_id'];

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password_db = "";
    $database = "stacatalinahealthsystem";
    $conn = new mysqli($servername, $username, $password_db, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the doctor's login ID exists
    $sql = "SELECT * FROM doctor WHERE doc_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $doctor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['doctor_id'] = $doctor_id;
        header("Location: doctor_dashboard.php");
        exit();
    } else {
        $message = "Doctor ID does not exist. Please register first.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Doctor Login</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: rgba(1, 67, 19, 0.26);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 40px;
      position: relative;
    }
    
    .back-btn-container {
      position: absolute;
      top: 20px;
      right: 20px;
    }

    .back-btn {
      background-color: #dc3545;
      color: white;
      border: none;
      padding: 8px 16px;
      font-size: 14px;
      border-radius: 5px;
      cursor: pointer;
    }

    .back-btn:hover {
      background-color: #c82333;
    }

    form {
      background: white;
      padding: 20px;
      border-radius: 10px;
      margin: 5px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: 270px;
    }

    input, button {
      width: 95%;
      margin-bottom: 10px;
      padding: 8px;
    }

    h2 {
      color:rgb(26, 45, 35) ;
      text-align: center;
    }

    .message {
      color: red;
      text-align: center;
      margin-top: 10px;
    }

    #doctorModal {
      display: flex;
      justify-content: center;
      align-items: center;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 999;
    }

    #doctorModalContent img {
      width: 50px;
      display: block;
      margin: 0 auto 15px;
    }

    #doctorModalContent {
      background: white;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      width: 320px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      position: relative;
    }

    input {
      width: 93%;
      margin-bottom: 10px;
      padding: 8px;
      font-size: 14px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }

    button {
      width: 100%;
      margin-bottom: 10px;
      padding: 8px;
      font-size: 14px;
      border: 1px solid #ddd;
      border-radius: 5px;
      background-color: #28a745;
      color: white;
      border: none;
      cursor: pointer;
    }

    button:hover {
      background-color: #218838;
    }

    p {
      margin-top: 15px;
    }

    a {
      text-decoration: none;
      color: rgb(12, 39, 14);
    }

    a:hover {
      text-decoration: underline;
    }

    button.close {
      position: absolute;
      top: 10px;
      right: 15px;
      background: none;
      border: none;
      font-size: 20px;
      cursor: pointer;
    }
  </style>
</head>
<body>

<?php if ($message): ?>
  <div id="doctorModal">
    <div id="doctorModalContent">
      <img src="https://th.bing.com/th/id/R.72c3255c7408f05c2a9690f2953ec41f?rik=6r%2fw3%2bAFcetWMQ&riu=http%3a%2f%2fwww.stacatalinailocossur.com%2fwp-content%2fuploads%2f2022%2f10%2fcropped-Santa_Catalina_Ilocos_Sur-1.png&ehk=8mGdqYPicxfsxkBlYyAQSIXh5p%2fPb9uqEqMixXF1TvM%3d&risl=&pid=ImgRaw&r=0" alt="Sta. Catalina Logo">
      <h2><?php echo $message; ?></h2>
      <button onclick="closeDoctorModal()" class="close">&times;</button>
    </div>
  </div>
<?php endif; ?>

<!-- Back Button Top Right -->
<div class="back-btn-container">
  <a href="admin_dashboard.php">
    <button type="button" class="back-btn">Back</button>
  </a>
</div>

<!-- Login Form -->
<h2>Doctor Login</h2>
<form action="doctor.php" method="POST">
  <label for="doctor_id">Doctor ID:</label>
  <input type="text" name="doctor_id" id="doctor_id" required>
  <label for="password">Password:</label>
  <input type="password" name="password" id="password" required>
  <button type="submit">Login</button>
</form>

<script>
  function closeDoctorModal() {
    document.getElementById("doctorModal").style.display = "none";
  }
</script>

</body>
</html>
