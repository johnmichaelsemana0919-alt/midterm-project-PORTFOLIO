<?php
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add new medicine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_medicine'])) {
    $brand = $_POST['brand_name'];
    $generic = $_POST['generic_name'];
    $desc = $_POST['description'];
    $expiry = $_POST['expiry_date'];
    $form = $_POST['dosage_form'];
    $category = $_POST['category'];

    $stmt = $conn->prepare("INSERT INTO medicine (brand_name, generic_name, description, expiry_date, dosage_form, category) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $brand, $generic, $desc, $expiry, $form, $category);
    $stmt->execute();
    $stmt->close();
}

// Update medicine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_medicine'])) {
    $id = $_POST['medicine_id'];
    $brand = $_POST['brand_name'];
    $generic = $_POST['generic_name'];
    $desc = $_POST['description'];
    $expiry = $_POST['expiry_date'];
    $form = $_POST['dosage_form'];
    $category = $_POST['category'];

    $stmt = $conn->prepare("UPDATE medicine SET brand_name=?, generic_name=?, description=?, expiry_date=?, dosage_form=?, category=? WHERE medicine_id=?");
    $stmt->bind_param("ssssssi", $brand, $generic, $desc, $expiry, $form, $category, $id);
    $stmt->execute();
    $stmt->close();
}

// Delete medicine
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM medicine WHERE medicine_id = $id");
}

// Fetch medicines
$medicineResult = $conn->query("SELECT * FROM medicine");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Medicine Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgba(1, 67, 19, 0.26);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        th {
            background: #198754;
            color: white;
        }
        form {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        label {
            font-weight: bold;
        }
        input, select, textarea {
            width: 200px;
            padding: 6px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 8px 15px;
            background: #198754;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-btn {
            background-color: red;
            padding: 5px 10px;
            border: none;
            color: white;
            cursor: pointer;
        }
        .back-btn {
            background-color: red;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            position: fixed;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>

<a href="admin_dashboard.php"><button class="back-btn">Back</button></a>

<h2>Medicine Dashboard</h2>

<!-- Add Medicine Form -->
<form method="POST">
    <input type="hidden" name="add_medicine" value="1">

    <label>Brand Name</label>
    <input type="text" name="brand_name" required>

    <label>Generic Name</label>
    <input type="text" name="generic_name" required>

    <label>Description</label>
    <textarea name="description" rows="3" required></textarea>

    <label>Expiry Date</label>
    <input type="date" name="expiry_date" required>

    <label>Dosage Form</label>
    <input type="text" name="dosage_form" required>

    <label>Category</label>
    <input type="text" name="category" required>

    <button type="submit">Add Medicine</button>
</form>

<h3>Medicine List</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Brand</th>
        <th>Generic</th>
        <th>Description</th>
        <th>Expiry</th>
        <th>Form</th>
        <th>Category</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $medicineResult->fetch_assoc()): ?>
        <tr>
            <td><?= $row['medicine_id'] ?></td>
            <td><?= htmlspecialchars($row['brand_name']) ?></td>
            <td><?= htmlspecialchars($row['generic_name']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td><?= htmlspecialchars($row['expiry_date']) ?></td>
            <td><?= htmlspecialchars($row['dosage_form']) ?></td>
            <td><?= htmlspecialchars($row['category']) ?></td>
            <td>
                <a href="?delete=<?= $row['medicine_id'] ?>" class="delete-btn" onclick="return confirm('Delete this medicine?')">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>

<?php $conn->close(); ?>
