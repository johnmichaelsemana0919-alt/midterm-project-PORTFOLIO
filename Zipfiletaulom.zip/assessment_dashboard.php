<?php
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Get the next ass_id manually
$result = $conn->query("SELECT MAX(ass_id) AS max_id FROM assessment");
$row = $result->fetch_assoc();
$next_ass_id = $row['max_id'] + 1;
if (!$next_ass_id) {
    $next_ass_id = 10031; // default start value
}

// Insert data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_assessment'])) {
    $ass_id = $_POST['ass_id'];
    $doc_id = $_POST['doc_id'];
    $patient_id = $_POST['patient_id'];
    $ass_date = $_POST['ass_date'];
    $heart_rate = $_POST['heart_rate'];
    $temperature = $_POST['temperature'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $blood_pressure = $_POST['blood_pressure'];

    $stmt = $conn->prepare("INSERT INTO assessment (ass_id, doc_id, patient_id, ass_date, heart_rate, temperature, height, weight, blood_pressure) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiissddds", $ass_id, $doc_id, $patient_id, $ass_date, $heart_rate, $temperature, $height, $weight, $blood_pressure);
    $stmt->execute();
    $stmt->close();

    header("Location: assessment_dashboard.php");
    exit();
}

// Delete data
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $conn->query("DELETE FROM assessment WHERE ass_id = $delete_id");
    header("Location: assessment_dashboard.php");
    exit();
}

// Fetch all data
$assessments = $conn->query("SELECT * FROM assessment");

// Fetch doctors from the database
$doctorQuery = "SELECT doc_id, CONCAT(f_name, ' ', m_name, ' ', l_name) AS full_name FROM doctor";
$doctorResult = $conn->query($doctorQuery);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assessment Dashboard</title>
    <style>
        body { font-family: Arial; background-color: rgba(1, 67, 19, 0.26);; padding: 20px; }
        form, table { background: #fff; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background: #198754; color: white; }
        input[type="text"], input[type="date"], input[type="number"] { padding: 8px; width: 99%; }
        button { padding: 8px 16px; background: #198754; color: white; border: none; cursor: pointer; border-radius: 4px; }
        button.delete { background: #dc3545; }
        /* Style for the Back button */
        .back-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .back-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<!-- Back Button -->
<a href="admin_dashboard.php"><button class="back-btn">Back</button></a>

<h2>Assessment Dashboard</h2>

<form method="POST">
    <input type="hidden" name="add_assessment" value="1">
    <label>Assessment ID:</label>
    <input type="number" name="ass_id" value="<?= $next_ass_id ?>" required><br><br>

    <label>Doctor:</label>
    <select name="doc_id" required>
        <option value="" disabled selected>Select Doctor</option>
        <?php while ($row = $doctorResult->fetch_assoc()): ?>
            <option value="<?= $row['doc_id'] ?>"><?= htmlspecialchars($row['full_name']) ?></option>
        <?php endwhile; ?>
    </select><br><br>

    <label>Patient ID:</label>
    <input type="number" name="patient_id" required><br><br>

    <label>Date:</label>
    <input type="date" name="ass_date" required><br><br>

    <label>Heart Rate:</label>
    <input type="text" name="heart_rate" required><br><br>

    <label>Temperature:</label>
    <input type="text" name="temperature" required><br><br>

    <label>Height:</label>
    <input type="text" name="height" required><br><br>

    <label>Weight:</label>
    <input type="text" name="weight" required><br><br>

    <label>Blood Pressure:</label>
    <input type="text" name="blood_pressure" required><br><br>

    <button type="submit">Add Assessment</button>
</form>

<h3>Existing Assessments</h3>
<table>
    <tr>
        <th>ass_id</th>
        <th>Doctor Name</th>
        <th>patient_id</th>
        <th>ass_date</th>
        <th>heart_rate</th>
        <th>temperature</th>
        <th>height</th>
        <th>weight</th>
        <th>blood_pressure</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $assessments->fetch_assoc()): ?>
        <tr>
            <td><?= $row['ass_id'] ?></td>
            <td>
                <?php
                // Fetch the doctor's name based on doc_id
                $doc_id = $row['doc_id'];
                $doctorQuery = "SELECT CONCAT(f_name, ' ', m_name, ' ', l_name) AS full_name FROM doctor WHERE doc_id = $doc_id";
                $doctorResult = $conn->query($doctorQuery);
                $doctor = $doctorResult->fetch_assoc();
                echo htmlspecialchars($doctor['full_name']);
                ?>
            </td>
            <td><?= $row['patient_id'] ?></td>
            <td><?= $row['ass_date'] ?></td>
            <td><?= $row['heart_rate'] ?></td>
            <td><?= $row['temperature'] ?></td>
            <td><?= $row['height'] ?></td>
            <td><?= $row['weight'] ?></td>
            <td><?= $row['blood_pressure'] ?></td>
            <td><a href="?delete_id=<?= $row['ass_id'] ?>" onclick="return confirm('Delete this assessment?')"><button class="delete">Delete</button></a></td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
