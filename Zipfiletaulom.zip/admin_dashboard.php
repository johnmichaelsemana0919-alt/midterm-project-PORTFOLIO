<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: LoginReg_index.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_patient'])) {
    $patient_id = $_POST['patient_id'];
    $doc_id = $_POST['doc_id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $guardian_name = $_POST['guardian_name'];
    $guard_type = $_POST['guard_type'];
    $blood_type = $_POST['blood_type'];

    $stmt = $conn->prepare("INSERT INTO patient (patient_id, doc_id, first_name, middle_name, last_name, birthdate, gender, contact, guardian_name, guard_type, blood_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisssssssss", $patient_id, $doc_id, $first_name, $middle_name, $last_name, $birthdate, $gender, $contact, $guardian_name, $guard_type, $blood_type);
    $stmt->execute();
    $stmt->close();
}

// Fetch existing patients
$patients = $conn->query("SELECT * FROM patient ORDER BY patient_id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - PATIENT</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: white;
    }
    .top-bar {
      background-color: rgba(1, 67, 19, 0.26);
      padding: 10px 0;
      width: 100%;
      text-align: center;
      position: fixed;
      top: 0;
      left: 0;
      z-index: 1;
      border-bottom: 1px solid #ccc;
      backdrop-filter: blur(5px);
    }
    .top-bar img {
      height: 50px;
    }
    .sidebar {
      width: 235px;
      height: 100vh;
      background: rgba(4, 41, 7, 0.64);
      color: white;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px 15px;
      overflow-y: auto;
      z-index: 2;
      box-sizing: border-box;
      transition: all 0.3s ease;
    }
    .hidden {
      display: none;
    }
    .sidebar-header {
      margin-bottom: 20px;
    }
    .sidebar a {
      margin-top: 10px;
      display: block;
      color: white;
      padding: 10px 0;
      text-decoration: none;
    
    }
    .dropdown-btn {
      background: none;
      border: none;
      color: white;
      padding: 10px 0;
      text-align: left;
      width: 100%;
      cursor: pointer;
      font-size: 16px;
    }
    .dropdown-content {
      display: none;
      flex-direction: column;
      background-color: rgba(19, 75, 40, 0.42);
      margin-left: 10px;
    }
    .dropdown-content a,
    .dropdown-content button {
      padding: 8px 10px;
      text-decoration: none;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      background: none;
      border: none;
      cursor: pointer;
      width: 100%;
      text-align: left;
    }
    .main {
      margin-top: 70px;
      margin-left: 240px;
      padding: 20px;
      background-color: #f8f9fa;
      color: #333;
      transition: margin-left 0.3s ease;
    }
    .role-icon {
      width: 20px;
      height: 20px;
    }
    .outside-hamburger {
      position: fixed;
      top: 25px;
      left: 10px;
      z-index: 3;
      background: rgba(4, 41, 7, 0.64);
      border: none;
      font-size: 14px;
      color: white;
      border-radius: 5px;
      padding: 5px 10px;
      cursor: pointer;
    }
    .sidebar-header h3 {
      margin-left: 40px;
      font-size: 16px;
      white-space: nowrap;
    }
    .outside-hamburger.show {
      display: block;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      margin-top: 15px;
    }
    table th, table td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: center;
    }
    table th {
      background-color: #198754;
      color: white;
    }
  </style>
</head>
<body>

<div class="main" id="mainContent">
  <h2>PATIENT</h2>

  <form method="POST" style="background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); display: flex; flex-wrap: wrap; gap: 15px;">
    <input type="hidden" name="add_patient" value="1">
    
    <input type="number" name="patient_id" placeholder="Patient ID" required style="flex: 1;">
    <input type="number" name="doc_id" placeholder="Doctor ID" required style="flex: 1;">
    <input type="text" name="first_name" placeholder="First Name" required style="flex: 1;">
    <input type="text" name="middle_name" placeholder="Middle Name" style="flex: 1;">
    <input type="text" name="last_name" placeholder="Last Name" required style="flex: 1;">
    <input type="date" name="birthdate" placeholder="Birthdate" required style="flex: 1;">
    <select name="gender" required style="flex: 1;">
      <option value="">Select Gender</option>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>
    <input type="text" name="contact" placeholder="Contact Number" required style="flex: 1;">
    <input type="text" name="guardian_name" placeholder="Guardian Name" required style="flex: 1;">
    <input type="text" name="guard_type" placeholder="Guardian Type" required style="flex: 1;">
    <input type="text" name="blood_type" placeholder="Blood Type" required style="flex: 1;">
    
    <button type="submit" style="flex: 1; background-color: #198754; color: white; border: none; padding: 10px; border-radius: 5px;">Add Patient</button>
  </form>

  <h3 style="margin-top: 30px;">Patient Records</h3>

  <table>
    <tr>
      <th>ID</th>
      <th>Doctor ID</th>
      <th>Name</th>
      <th>Birthdate</th>
      <th>Gender</th>
      <th>Contact</th>
      <th>Guardian</th>
      <th>Guardian Type</th>
      <th>Blood Type</th>
    </tr>
    <?php while ($row = $patients->fetch_assoc()): ?>
    <tr>
      <td><?= $row['patient_id'] ?></td>
      <td><?= $row['doc_id'] ?></td>
      <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name']) ?></td>
      <td><?= $row['birthdate'] ?></td>
      <td><?= $row['gender'] ?></td>
      <td><?= $row['contact'] ?></td>
      <td><?= $row['guardian_name'] ?></td>
      <td><?= $row['guard_type'] ?></td>
      <td><?= $row['blood_type'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php $conn->close(); ?>

<!-- Top bar -->
<div class="top-bar">
  <img src="https://png.pngtree.com/png-clipart/20230515/original/pngtree-health-logo-png-image_9161429.png">
</div>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <h3>RURAL HEALTH UNIT</h3>
  </div>

  <button class="dropdown-btn" onclick="toggleDropdown()">▼ Admin Roles</button>
  <div class="dropdown-content" id="adminRolesDropdown">
    <button onclick="window.location.href='doctor.php'"><img src="https://static.vecteezy.com/system/resources/previews/013/096/566/original/doctor-flat-style-icon-free-vector.jpg" class="role-icon">Doctor</button>
    <a href="login_nurse.php"><img src="https://tse3.mm.bing.net/th/id/OIP.fkp4kVjQRC96x8m5CiC0TgHaHZ?cb=iwc1&rs=1&pid=ImgDetMain" class="role-icon">Nurse</a>
    <a href="bhw_dashboard.php"><img src="https://tse4.mm.bing.net/th/id/OIP.LQBVQv6Ht6JZwIbzm40Y4wAAAA?cb=iwc1&rs=1&pid=ImgDetMain" class="role-icon">BHW</a>
  </div>
  <a href="medicine_dashboard.php">Medicine</a>
  <a href="assessment_dashboard.php">Assessment</a>
  <a href="prescription_dashboard.php">Prescription</a>
  <a href="medicineinventory.php">Medicine Inventory</a>
  <a href="log_admin.php">Admin</a>
  <hr>
  <a href="logout.php?logout=true">Logout</a>
</div>

<!-- Hamburger Button (Floating) -->
<button class="outside-hamburger" id="outsideHamburger" onclick="toggleSidebar()">☰</button>

<script>
  function toggleDropdown() {
    const dropdown = document.getElementById("adminRolesDropdown");
    dropdown.style.display = dropdown.style.display === "flex" ? "none" : "flex";
  }

  function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const main = document.getElementById("mainContent");

    sidebar.classList.toggle("hidden");

    if (sidebar.classList.contains("hidden")) {
      main.style.marginLeft = "0";
    } else {
      main.style.marginLeft = "240px";
    }
  }
</script>

</body>
</html>
