<!DOCTYPE html>
<html>
<head>
    <title>Admin Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('https://th.bing.com/th/id/R.2b1bf1cbb2c627549f7b06adf17e592a?rik=YKR3brHJWj0LsQ&riu=http%3a%2f%2fwww.stacatalinailocossur.com%2fwp-content%2fuploads%2f2023%2f04%2fMSC.jpg&ehk=bFDoyJuyGmcwWd2eyedz64bgRiaZYd5M8IXumd9YMLY%3d&risl=&pid=ImgRaw&r=0');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
        }

        .top-right {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .back-button {
            background-color: #6c757d;
            color: white;
            padding: 8px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #5a6268;
        }

        .content {
            text-align: center;
            padding-top: 100px;
            color: white;
            text-shadow: 1px 1px 2px black;
        }

        .button-container {
            color:black;
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 40px;
        }

        .green-button {
            background-color: #28a745;
            color: white;
            padding: 8px 30px;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
        }

        .green-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

    <div class="top-right">
        <a href="admin_dashboard.php" class="back-button">Back</a>
    </div>

    <div class="content">
        <h1>Admin Form</h1>
        <div class="button-container">
            <a href="nurse.php" class="green-button">Add Nurse</a>
            <a href="doctor_register.php" class="green-button">Add Doctor</a>
            <a href="bhw_form.php" class="green-button">Add BHW</a>
        </div>
    </div>

</body>
</html>
