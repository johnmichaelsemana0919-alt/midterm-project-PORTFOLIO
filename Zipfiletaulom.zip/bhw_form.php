<?php
session_start();

$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Insert new BHW info if form is submitted
if (isset($_POST['add_bhw'])) {
    $bhw_id = $_POST['bhw_id'];
    $bhw_name = $_POST['bhw_name'];
    $barangay = $_POST['barangay'];

    $insertQuery = "INSERT INTO bhw (bhw_id, bhw_name, barangay) 
                    VALUES ('$bhw_id', '$bhw_name', '$barangay')";
    
    if ($conn->query($insertQuery) === TRUE) {
        header("Location: bhw_form.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Get all BHWs and their request quantities using JOIN
$query = "SELECT bhw.bhw_id, bhw.bhw_name, bhw.barangay, rm.req_quantity
          FROM bhw
          LEFT JOIN requested_medicine rm ON bhw.bhw_id = rm.bhw_id";

$bhwResult = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BHW Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 20px;
        }

        h2, h3 {
            text-align: center;
        }

        .form-container {
            background-color: white;
            padding: 10px;
            margin-bottom: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .form-header h3 {
            margin: 0;
        }

        .add-bhw-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 5px;
        }

        .add-bhw-btn:hover {
            background-color: #45a049;
        }

        input, select {
            margin: 3px 0;
            padding: 6px;
            width: 90%;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .horizontal-form {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .horizontal-form div {
            flex: 1 1 30%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 6px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .logout-btn:hover {
            background-color: #d32f2f;
        }

        .section-spacer {
            height: 30px;
        }

        .no-records {
            text-align: center;
            color: #555;
        }
    </style>
</head>
<body>

    <!-- Back Button (Right-Aligned) -->
    <div style="text-align: right; margin-bottom: 10px;">
        <form action="admin_dashboard.php?logout=true" method="POST" style="display: inline;">
            <button type="submit" class="logout-btn">Back</button>
        </form>
    </div>

    <h2>BHW Management</h2>

    <!-- Add BHW Form -->
    <div class="form-container">
        <div class="form-header">
            <h3>Add BHW</h3>
            <button type="submit" form="addBHWForm" name="add_bhw" class="add-bhw-btn">Add BHW</button>
        </div>
        <form method="POST" id="addBHWForm">
            <div class="horizontal-form">
                <div><input type="text" name="bhw_id" placeholder="BHW ID" required></div>
                <div><input type="text" name="bhw_name" placeholder="BHW Name" required></div>
                <div><input type="text" name="barangay" placeholder="Barangay" required></div>
            </div>
        </form>
    </div>

    <!-- Spacer -->
    <div class="section-spacer"></div>

    <!-- BHW List Table -->
    <h3>Registered BHWs & Medicine Requests</h3>
    <?php if ($bhwResult && $bhwResult->num_rows > 0): ?>
        <table>
            <tr>
                <th>BHW ID</th>
                <th>Name</th>
                <th>Barangay</th>
                <th>Requested Quantity</th>
            </tr>
            <?php while ($row = $bhwResult->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['bhw_id']) ?></td>
                    <td><?= htmlspecialchars($row['bhw_name']) ?></td>
                    <td><?= htmlspecialchars($row['barangay']) ?></td>
                    <td><?= htmlspecialchars($row['req_quantity'] ?? '0') ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p class="no-records">No BHWs or requests found.</p>
    <?php endif; ?>

</body>
</html>
