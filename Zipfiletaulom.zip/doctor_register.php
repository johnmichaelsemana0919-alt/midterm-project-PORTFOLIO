<?php
session_start();

$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Insert new doctor info if form is submitted
if (isset($_POST['add_doctor'])) {
    $doc_id = $_POST['doc_id'];
    $position = $_POST['position'];
    $f_name = $_POST['f_name'];
    $m_name = $_POST['m_name'];
    $l_name = $_POST['l_name'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $contact_no = $_POST['contact_no'];
    $gender = $_POST['gender'];

    $insertQuery = "INSERT INTO doctor (doc_id, position, f_name, m_name, l_name, birthdate, address, contact_no, gender) 
                    VALUES ('$doc_id', '$position', '$f_name', '$m_name', '$l_name', '$birthdate', '$address', '$contact_no', '$gender')";
    
    if ($conn->query($insertQuery) === TRUE) {
        header("Location: admin_form.php".$_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Get all doctors for the dropdown
$doctorsList = $conn->query("SELECT doc_id, f_name, m_name, l_name FROM doctor");

// Fix: Ensure $doctor_id is always defined
$doctor_id = isset($_POST['doctor_id']) ? $_POST['doctor_id'] : '';
$selectedDoctorId = $doctor_id;

// Get doctor info based on selected doctor
$doctorInfo = $conn->query("SELECT * FROM doctor WHERE doc_id = '$selectedDoctorId'");

// Query for patient records
$doctorFilterQuery = " AND (assessment.doc_id = '$selectedDoctorId' 
                            OR prescription.doc_id = '$selectedDoctorId' 
                            OR nurse.doc_id = '$selectedDoctorId'
                            OR patient.doc_id = '$selectedDoctorId')";

$sql = "
SELECT 
    patient.patient_id,
    patient.first_name AS patient_first_name, 
    patient.middle_name AS patient_middle_name, 
    patient.last_name AS patient_last_name, 
    assessment.ass_id, 
    prescription.prescription_id, 
    nurse.full_name AS nurse_name
FROM patient
LEFT JOIN assessment ON assessment.patient_id = patient.patient_id
LEFT JOIN prescription ON prescription.patient_id = patient.patient_id
LEFT JOIN nurse ON nurse.patient_id = patient.patient_id
WHERE 1=1 $doctorFilterQuery
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 20px;
            position: relative;
        }

        h2, h3 {
            text-align: center;
        }

        .no-records {
            text-align: center;
            margin-top: 20px;
            color: #ff6347;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .form-container {
            background-color: white;
            padding: 10px;
            margin-bottom: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }

        .form-header h3 {
            margin: 0;
        }

        .add-doctor-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 5px;
        }

        .add-doctor-btn:hover {
            background-color: #45a049;
        }

        input, select {
            margin: 3px 0;
            padding: 6px;
            width: 90%;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .horizontal-form {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .horizontal-form div {
            flex: 1 1 20%;
        }

        .section-spacer {
            height: 30px;
        }

        .info-table th {
            text-align: left;
            padding-right: 10px;
            background-color: #f2f2f2;
        }

        .info-table td {
            padding: 6px;
            background-color: #fff;
        }

        .doctor-info-container {
            margin-top: 30px;
        }

        select {
            width: 60%;
        }

        .inline-form {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
        }

        .inline-form div {
            flex: 1 1 48%;
        }
    </style>
</head>
<body>

    <!-- Logout -->
    <form action="admin_dashboard.php?logout=true" method="POST">
        <button type="submit" class="logout-btn">Back</button>
    </form>

    <!-- Welcome Heading -->
    <h2>
        <?php if (!empty($doctor_id)): ?>
            Welcome Doctor <?= htmlspecialchars($doctor_id) ?>
        <?php else: ?>
            Welcome Doctor
        <?php endif; ?>
    </h2>

    <!-- Add Doctor Form -->
    <div class="form-container">
        <div class="form-header">
            <h3>Add Doctor Info</h3>
            <button type="submit" form="addDoctorForm" name="add_doctor" class="add-doctor-btn">Add Doctor</button>
        </div>
        <form method="POST" id="addDoctorForm">
            <div class="horizontal-form">
                <div><input type="text" name="doc_id" placeholder="Doc ID" required></div>
                <div><input type="text" name="position" placeholder="Position" required></div>
                <div><input type="text" name="f_name" placeholder="First Name" required></div>
                <div><input type="text" name="m_name" placeholder="Middle Name"></div>
                <div><input type="text" name="l_name" placeholder="Last Name" required></div>
                <div><input type="date" name="birthdate" required></div>
                <div><input type="text" name="address" placeholder="Address" required></div>
                <div><input type="text" name="contact_no" placeholder="Contact No" required></div>
                <div>
                    <select name="gender" required style="width: 60%; padding: 6px;">
                        <option value="" disabled selected>Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
            </div>
        </form>
    </div>

    <!-- Spacer -->
    <div class="section-spacer"></div>

    <!-- Select Doctor Dropdown -->
    <form method="POST">
        <h3>Select Doctor to View Assisted Patients</h3>
        <select name="doctor_id" onchange="this.form.submit()" required style="width: 100%; padding: 6px;">
            <option value="" disabled selected>Select Doctor</option>
            <?php while ($doc = $doctorsList->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($doc['doc_id']) ?>" <?= ($selectedDoctorId == $doc['doc_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($doc['f_name']) . " " . htmlspecialchars($doc['m_name']) . " " . htmlspecialchars($doc['l_name']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </form>

    <!-- Display Patient Records -->
    <h3>Patient Records Assisted</h3>
    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Patient Name</th><th>Patient ID</th><th>Assessment ID</th><th>Prescription ID</th><th>Nurse Name</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['patient_first_name']) . " " . 
                         htmlspecialchars($row['patient_middle_name']) . " " . 
                         htmlspecialchars($row['patient_last_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['patient_id']) . "</td>";
            echo "<td>" . (!empty($row['ass_id']) ? htmlspecialchars($row['ass_id']) : 'N/A') . "</td>";
            echo "<td>" . (!empty($row['prescription_id']) ? htmlspecialchars($row['prescription_id']) : 'N/A') . "</td>";
            echo "<td>" . (!empty($row['nurse_name']) ? htmlspecialchars($row['nurse_name']) : 'N/A') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='no-records'>No records found for the selected doctor.</p>";
    }
    ?>

    <!-- Display Doctor Info -->
    <?php if ($doctorInfo->num_rows > 0): ?>
        <?php 
            $doctor = $doctorInfo->fetch_assoc(); 
            $birthDate = new DateTime($doctor['birthdate']);
            $today = new DateTime();
            $age = $today->diff($birthDate)->y;
        ?>
        <div class="doctor-info-container">
            <h3>Doctor Information</h3>
            <table class="info-table">
                <tr><th>Doctor ID</th><td><?= htmlspecialchars($doctor['doc_id']) ?></td></tr>
                <tr><th>Name</th><td><?= htmlspecialchars($doctor['f_name'] . " " . $doctor['m_name'] . " " . $doctor['l_name']) ?></td></tr>
                <tr><th>Position</th><td><?= htmlspecialchars($doctor['position']) ?></td></tr>
                <tr><th>Birthdate</th><td><?= htmlspecialchars($doctor['birthdate']) ?></td></tr>
                <tr><th>Age</th><td><?= $age ?> years old</td></tr>
                <tr><th>Address</th><td><?= htmlspecialchars($doctor['address']) ?></td></tr>
                <tr><th>Contact No</th><td><?= htmlspecialchars($doctor['contact_no']) ?></td></tr>
                <tr><th>Gender</th><td><?= htmlspecialchars($doctor['gender']) ?></td></tr>
            </table>
        </div>
    <?php endif; ?>

</body>
</html>
