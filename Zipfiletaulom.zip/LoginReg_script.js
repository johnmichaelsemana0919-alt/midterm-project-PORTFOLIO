// Get references to the necessary DOM elements
const showLogin = document.getElementById('showLogin'); // Button to show the login form
const showRegister = document.getElementById('showRegister'); // Button to show the register form
const loginBox = document.querySelector('.login-box'); // Login form container
const registerBox = document.querySelector('.register-box'); // Register form container

// Event listener for showing the login form
showLogin.addEventListener('click', () => {
    // Move the register form off-screen by adding the 'move-right' class
    registerBox.classList.add;
    // Remove the 'active' class to hide the register form
    registerBox.classList.remove('active');

    // Move the login form into view by adding the 'move-left' class
    loginBox.classList.add;
    // Make the login form visible by adding the 'active' class
    loginBox.classList.add('active');

    // After the animation (500ms), remove the 'move-left' class to complete the animation
    setTimeout(() => {
        loginBox.classList.remove('move-left');
    }, 500);
});

// Event listener for showing the register form
showRegister.addEventListener('click', () => {
    // Move the login form off-screen by adding the 'move-right' class
    loginBox.classList.add('move-right');
    // Remove the 'active' class to hide the login form
    loginBox.classList.remove('active');

    // Move the register form into view by adding the 'move-left' class
    registerBox.classList.add('move-left');
    // Make the register form visible by adding the 'active' class
    registerBox.classList.add('active');

    // After the animation (500ms), remove the 'move-left' class to complete the animation
    setTimeout(() => {
        registerBox.classList.remove('move-left');
    }, 500);
});
