<?php
session_start();

if (!isset($_SESSION['nurse_id'])) {
    header("Location: login_nurse.php");
    exit();
}

$nurse_id = $_SESSION['nurse_id'];
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Fetch assigned patients and corresponding doctors
$join_stmt = $conn->prepare("
    SELECT 
        nurse.nurse_id,
        nurse.patient_id, 
        patient.first_name AS patient_first,
        patient.middle_name AS patient_middle,
        patient.last_name AS patient_last,
        doctor.doc_id,
        doctor.f_name AS doctor_first,
        doctor.m_name AS doctor_middle,
        doctor.l_name AS doctor_last
    FROM nurse
    JOIN patient ON nurse.patient_id = patient.patient_id
    JOIN doctor ON nurse.doc_id = doctor.doc_id
    WHERE nurse.nurse_id = ?
");
$join_stmt->bind_param("s", $nurse_id);
$join_stmt->execute();
$join_result = $join_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nurse Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            padding: 20px;
            margin: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #e0f2f1;
        }

        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 12px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
        }

        .logout-btn:hover {
            background-color: #e53935;
        }

        .no-records {
            text-align: center;
            color: #c62828;
            font-size: 16px;
        }

        .patients-table {
            margin: 0 auto;
            max-width: 1000px;
            width: 100%;
        }
    </style>
</head>
<body>

    <form action="admin_dashboard.php" method="POST">
        <button type="submit" class="logout-btn">Back</button>
    </form>

    <h2>Assigned Patients & Their Doctors</h2>

    <?php
    if ($join_result->num_rows > 0) {
        echo "<table class='patients-table'>";
        echo "<tr>
                <th>Nurse ID</th>
                <th>Patient ID</th>
                <th>Patient Name</th>
                <th>Doctor ID</th>
                <th>Doctor Name</th>
              </tr>";
        while ($row = $join_result->fetch_assoc()) {
            $patient_name = htmlspecialchars($row['patient_first']) . " " .
                            htmlspecialchars($row['patient_middle']) . " " .
                            htmlspecialchars($row['patient_last']);
            $doctor_name = htmlspecialchars($row['doctor_first']) . " " .
                           htmlspecialchars($row['doctor_middle']) . " " .
                           htmlspecialchars($row['doctor_last']);

            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['nurse_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['patient_id']) . "</td>";
            echo "<td>$patient_name</td>";
            echo "<td>" . htmlspecialchars($row['doc_id']) . "</td>";
            echo "<td>$doctor_name</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='no-records'>No assigned patients or doctors found.</p>";
    }

    $conn->close();
    ?>

</body>
</html>
