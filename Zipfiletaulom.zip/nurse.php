<?php
session_start();

$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Insert new nurse info if form is submitted
if (isset($_POST['add_nurse'])) {
    $full_name = $_POST['nurse_full_name'];
    $position = $_POST['nurse_position'];
    $patient_id = $_POST['nurse_patient_id'];

    // Get corresponding doc_id from patient
    $docQuery = $conn->query("SELECT doc_id FROM patient WHERE patient_id = '$patient_id'");
    $docRow = $docQuery->fetch_assoc();
    $doc_id = $docRow['doc_id'];

    // Generate nurse_id starting from 20001
    $result = $conn->query("SELECT MAX(nurse_id) AS max_id FROM nurse");
    $row = $result->fetch_assoc();
    $max_id = $row['max_id'];

    $nurse_id = ($max_id === null) ? 20001 : $max_id + 1;

    $insertNurse = "INSERT INTO nurse (nurse_id, patient_id, doc_id, full_name, position)
                    VALUES ('$nurse_id', '$patient_id', '$doc_id', '$full_name', '$position')";

    if ($conn->query($insertNurse) === TRUE) {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error inserting nurse: " . $conn->error;
    }
}

// Get all nurses for dropdown
$nursesList = $conn->query("SELECT nurse_id, full_name FROM nurse");

$nurse_id = isset($_POST['nurse_id']) ? $_POST['nurse_id'] : '';
$selectedNurseId = $nurse_id;

// Get nurse info
$nurseInfo = $conn->query("SELECT * FROM nurse WHERE nurse_id = '$selectedNurseId'");

// Get assisted patients
$filterQuery = " AND nurse.nurse_id = '$selectedNurseId'";
$sql = "
SELECT 
    patient.patient_id,
    patient.first_name, 
    patient.middle_name, 
    patient.last_name, 
    assessment.ass_id,
    prescription.prescription_id
FROM patient
LEFT JOIN nurse ON nurse.patient_id = patient.patient_id
LEFT JOIN assessment ON assessment.patient_id = patient.patient_id
LEFT JOIN prescription ON prescription.patient_id = patient.patient_id
WHERE 1=1 $filterQuery
";
$result = $conn->query($sql);

// Get patient list for dropdown
$patientsList = $conn->query("SELECT patient_id FROM patient");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nurse Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 20px;
        }
        h2, h3 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .form-container {
            background-color: white;
            padding: 10px;
            margin-bottom: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        input {
            padding: 4px;
            width: 99%;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 14px;
        }
        select {
            padding: 4px;
            width: 100%;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 14px
        }
        .horizontal-form {
            display: flex;
            gap: 10px;
        }
        .horizontal-form div {
            flex: 1;
        }
        .add-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 5px;
        }
        .add-btn:hover {
            background-color: #45a049;
        }
        .back-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 5px;
        }
        .back-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<!-- Top-right Back Button -->
<div style="text-align:right; margin-bottom: 10px;">
    <a href="admin_dashboard.php" style="text-decoration:none;">
        <button class="back-btn">Back</button>
    </a>
</div>

<h2>Nurse Dashboard</h2>

<!-- Add Nurse Info Form -->
<div class="form-container">
    <h3>Add Nurse Information</h3>
    <form method="POST">
        <div class="horizontal-form">
            <div><input type="text" name="nurse_full_name" placeholder="Full Name" required></div>
            <div><input type="text" name="nurse_position" placeholder="Position" required></div>
            <div>
                <select name="nurse_patient_id" required>
                    <option value="" disabled selected>Select Patient ID</option>
                    <?php while ($pat = $patientsList->fetch_assoc()): ?>
                        <option value="<?= $pat['patient_id'] ?>"><?= $pat['patient_id'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div><button type="submit" name="add_nurse" class="add-btn">Add Nurse</button></div>
        </div>
    </form>
</div>

<!-- Select Nurse Dropdown -->
<form method="POST">
    <h3>Select Nurse to View Assisted Patients</h3>
    <select name="nurse_id" onchange="this.form.submit()" required>
        <option value="" disabled selected>Select Nurse</option>
        <?php while ($n = $nursesList->fetch_assoc()): ?>
            <option value="<?= $n['nurse_id'] ?>" <?= ($selectedNurseId == $n['nurse_id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($n['full_name']) ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>

<!-- Display Patient Records -->
<h3>Patients Assisted</h3>
<?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>Patient Name</th>
            <th>Patient ID</th>
            <th>Assessment ID</th>
            <th>Prescription ID</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name']) ?></td>
                <td><?= htmlspecialchars($row['patient_id']) ?></td>
                <td><?= $row['ass_id'] ?? 'N/A' ?></td>
                <td><?= $row['prescription_id'] ?? 'N/A' ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p style="text-align:center;color:#888">No records found.</p>
<?php endif; ?>

<!-- Display Nurse Info -->
<?php if ($nurseInfo->num_rows > 0): ?>
    <?php $nurse = $nurseInfo->fetch_assoc(); ?>
    <h3>Nurse Information</h3>
    <table>
        <tr><th>Nurse ID</th><td><?= htmlspecialchars($nurse['nurse_id']) ?></td></tr>
        <tr><th>Full Name</th><td><?= htmlspecialchars($nurse['full_name']) ?></td></tr>
        <tr><th>Position</th><td><?= htmlspecialchars($nurse['position']) ?></td></tr>
        <tr><th>Patient ID</th><td><?= htmlspecialchars($nurse['patient_id']) ?></td></tr>
        <tr><th>Doctor ID</th><td><?= htmlspecialchars($nurse['doc_id']) ?></td></tr>
    </table>
<?php endif; ?>

</body>
</html>
