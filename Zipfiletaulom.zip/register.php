<?php
// Initialize variables for message and a boolean flag to check if the user exists
$message = "";
$boolean = false;

// Database connection
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted using the POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form inputs and trim any extra spaces from them
    $username = trim($_POST['username']);
    $idnum = trim($_POST['idnum']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Validate the email format using PHP's filter_var function
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format.";
    }
    // Check if the password and confirm password fields match
    elseif ($password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        // Check if the ID number or email already exists in the database
        $sql = "SELECT idnum, email FROM registration_tbl WHERE idnum = ? OR email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $idnum, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Check if the ID number or email already exists
        if ($result->num_rows > 0) {
            $message = "Account with this ID number or email already exists!";
            $boolean = true;
        }

        // If the user doesn't exist in the database, proceed with registration
        if (!$boolean) {
            // Hash the password using password_hash function for security
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert the new user into the registration_tbl
            $insert_sql = "INSERT INTO registration_tbl (idnum, username, email, password) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("ssss", $idnum, $username, $email, $hashed_password);

            // Execute the insert statement
            if ($stmt->execute()) {
                $message = "Registration successful! Please login.";
            } else {
                $message = "Error: " . $stmt->error;
            }
        }
        $stmt->close(); // Close the prepared statement
    }

    // Close the database connection
    $conn->close();

    // Show the message (error or success) and redirect to the login page
    echo "<script>
            alert('$message');
            window.location.href = 'LoginReg_index.html'; // Redirect to the login page
          </script>";
    exit(); // Exit the script to prevent further execution
}
?>
