<?php
session_start();
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nurse_id = $_POST['nurse_id'] ?? '';

    // Since no password is handled, we only verify nurse_id exists
    $stmt = $conn->prepare("SELECT nurse_id FROM nurse WHERE nurse_id = ?");
    $stmt->bind_param("s", $nurse_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $_SESSION['nurse_id'] = $nurse_id;
        header("Location: nurse_dashboard.php");
        exit();
    } else {
        $error = "Nurse ID not found.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Nurse Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgba(1, 67, 19, 0.26);
            padding: 40px;
            margin: 0;
        }

        .back-btn-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .back-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 16px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        .back-btn:hover {
            background-color: #c82333;
        }

        .form-container {
            width: 400px;
            margin: auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            color: #000;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 93%;
            padding: 10px;
            border: 1px solid #000;
            border-radius: 5px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #66bb6a;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #5da05e;
        }

        .register-link {
            margin-top: 15px;
            text-align: center;
        }

        .register-link a {
            color: rgb(5, 103, 42);
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<!-- Back to Admin Button -->
<div class="back-btn-container">
    <a href="admin_dashboard.php" class="back-btn">Back</a>
</div>

<div class="form-container">
    <h2>Nurse Login</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label for="nurse_id">Nurse ID</label>
            <input type="text" name="nurse_id" required>
        </div>
        <div class="form-group">
            <label for="password">Password (optional)</label>
            <input type="password" name="password">
        </div>
        <input type="submit" value="Login">
    </form>
</div>

</body>
</html>
