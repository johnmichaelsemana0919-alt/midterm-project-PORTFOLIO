<?php
session_start();

if (!isset($_SESSION['doctor_id'])) {
    header("Location: doctor.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

// SQL query: use patient_id to JOIN with assessment, prescription, and nurse
$sql = "
SELECT 
    patient.patient_id,
    patient.first_name AS patient_first_name, 
    patient.middle_name AS patient_middle_name, 
    patient.last_name AS patient_last_name, 
    assessment.ass_id, 
    prescription.prescription_id, 
    nurse.full_name AS nurse_name
FROM patient
LEFT JOIN assessment ON assessment.patient_id = patient.patient_id
LEFT JOIN prescription ON prescription.patient_id = patient.patient_id
LEFT JOIN nurse ON nurse.patient_id = patient.patient_id
WHERE 
    assessment.doc_id = '$doctor_id' 
    OR prescription.doc_id = '$doctor_id' 
    OR nurse.doc_id = '$doctor_id'
    OR patient.doc_id = '$doctor_id'
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 20px;
            position: relative;
        }

        h2, h3 {
            text-align: center;
        }

        .no-records {
            text-align: center;
            margin-top: 20px;
            color: #ff6347;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Style for the logout button */
        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #ff6347;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }

        .logout-btn:hover {
            background-color: #e55347;
        }
    </style>
</head>
<body>

    <!-- Logout button -->
    <form action="admin_dashboard.php?logout=true" method="POST">
        <button type="submit" class="logout-btn">Back</button>
    </form>

    <h2>Welcome Doctor <?= htmlspecialchars($doctor_id) ?></h2>
    <h3>Patient Records You Assisted</h3>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Patient Name</th><th>Patient ID</th><th>Assessment ID</th><th>Prescription ID</th><th>Nurse Name</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['patient_first_name']) . " " . 
                         htmlspecialchars($row['patient_middle_name']) . " " . 
                         htmlspecialchars($row['patient_last_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['patient_id']) . "</td>";
            echo "<td>" . (!empty($row['ass_id']) ? htmlspecialchars($row['ass_id']) : 'N/A') . "</td>";
            echo "<td>" . (!empty($row['prescription_id']) ? htmlspecialchars($row['prescription_id']) : 'N/A') . "</td>";
            echo "<td>" . (!empty($row['nurse_name']) ? htmlspecialchars($row['nurse_name']) : 'N/A') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='no-records'>No records found for your patients.</p>";
    }

    $conn->close();
    ?>

</body>
</html>
