<?php
session_start();
$conn = new mysqli("localhost", "root", "", "stacatalinahealthsystem");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_id = $_POST['admin_id'] ?? '';

    // Check if admin_id exists in the admin table
    $stmt = $conn->prepare("SELECT admin_id FROM admin WHERE admin_id = ?");
    $stmt->bind_param("s", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $_SESSION['admin_id'] = $admin_id;
        header("Location: admin_form.php"); // redirect to the actual admin form
        exit();
    } else {
        $error = "Admin ID not found.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgba(1, 67, 19, 0.26);
            padding: 40px;
        }

        .form-container {
            width: 400px;
            margin: auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            color: #000;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 93%;
            padding: 10px;
            border: 1px solid #000;
            border-radius: 5px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #66bb6a;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #66bb6a;
        }

        .register-link {
            margin-top: 15px;
            text-align: center;
        }

        .register-link a {
            color: rgb(5, 103, 42);
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }

        .back-btn-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .back-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
        }

        .back-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<div class="back-btn-container">
    <a href="admin_dashboard.php">
        <button type="button" class="back-btn">Back</button>
    </a>
</div>

<div class="form-container">
    <h2>Admin Login</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label for="admin_id">Admin ID</label>
            <input type="text" name="admin_id" required>
        </div>
        <div class="form-group">
            <label for="password">Password (optional)</label>
            <input type="password" name="password">
        </div>
        <input type="submit" value="Login">
    </form>
</div>

</body>
</html>
